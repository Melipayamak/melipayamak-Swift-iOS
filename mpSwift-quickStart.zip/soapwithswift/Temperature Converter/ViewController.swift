//
//  ViewController.swift
//  Temperature Converter
//
//  Created by Farhad on 10/24/14.
//  Copyright (c) 2014 Web In Dream. All rights reserved.
//

import UIKit

//Step 1: Add protocol names that we will be delegating.

class ViewController: UIViewController, UITextFieldDelegate, NSURLConnectionDelegate,NSURLConnectionDataDelegate,  XMLParserDelegate {
    
    var mutableData:NSMutableData  = NSMutableData()
    var currentElementName:String = ""

    @IBOutlet var txtCelsius : UITextField!
    @IBOutlet var txtFahrenheit : UITextField!
    
    @IBAction func actionConvert(_ sender: Any) {
        
        let username : String = "username"
        let password : String = "password"
        let to : String = "09123456789"
        let from : String = "5000..."
        let text : String = "SOAP Test for iOS Swift"
        let isFlash: Bool = false
//
//        let username: String = "username"
//        let password: String = "password"
//        let from: String = "5000..."
//        var to: String = "09123456789"
//        var text: String = "تست وب سرویس ملی پیامک"
//        var isFlash: Bool = false
//        var soapClient = SoapClient(user: username, pass: password)
//        soapClient.SendSimpleSMS2(to: to, from: from, msg: text, isFlash: isFlash)
        
        var restClient = RestClient(user: username, pass: password)
        restClient.Send(to: to, from: from, message: text, isflash: isFlash)
    
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // NSURLConnectionDelegate
    
    // NSURL
    
    func connection(_ connection: NSURLConnection, didFailWithError error: Error) {
        print("connection error = \(error)")
    }
    
    func connection(_ connection: NSURLConnection, didReceive response: URLResponse) {
        mutableData = NSMutableData()
    }
    
    
    func connection(_ connection: NSURLConnection, didReceive data: Data) {
        self.mutableData.append(data)
    }


    
//    // NSXMLParserDelegate
//    
//    
//    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
//        currentElementName = elementName
//    }
//    
//    
//    
//    func parser(_ parser: XMLParser, foundCharacters string: String) {
//        if currentElementName == "SendSimpleSMS2Result" {
//            txtFahrenheit.text = string
//        }
//    }
//    
    
    
   
    
    func connectionDidFinishLoading(_ connection: NSURLConnection) {

//        let json = try? JSONSerialization.jsonObject(with: mutableData as Data, options: [])
        let response : RestResponse = RestResponse(mutableData: mutableData)
//        print(response.StrRetStatus)
        
        print("response memeber is : \(response.StrRetStatus)")
        
//        let xmlParser = XMLParser(data: mutableData as Data)
//        xmlParser.delegate = self
//        xmlParser.parse()
//        xmlParser.shouldResolveExternalEntities = true
    }

}

